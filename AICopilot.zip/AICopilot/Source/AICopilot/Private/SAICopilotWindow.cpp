#include "SAICopilotWindow.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonReader.h"
#include "Dom/JsonObject.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "AICopilotSettings.h"
#include "SAICopilotSettings.h"
#include "Framework/Application/SlateApplication.h"
#include "IPythonScriptPlugin.h"

// NEW: Headers
#include "HAL/PlatformApplicationMisc.h"
#include "Engine/Selection.h"
#include "EdGraph/EdGraphNode.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Editor/UnrealEd/Public/FileHelpers.h"
#include "Exporters/Exporter.h"
#include "UnrealEdGlobals.h"
#include "Editor/UnrealEdEngine.h"
#include "Editor/EditorEngine.h"

#define LOCTEXT_NAMESPACE "AICopilot"

void SAICopilotWindow::Construct(const FArguments& InArgs)
{
	ChildSlot
	[
		SNew(SVerticalBox)
		
		// Top Toolbar
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(5)
		.HAlign(HAlign_Fill)
		[
			SNew(SHorizontalBox)
			
			// Left: Chat Tools
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2)
			[
				SNew(SButton)
				.Text(LOCTEXT("ClearChatButton", "清空"))
				.ToolTipText(LOCTEXT("ClearChatTooltip", "清空聊天记录"))
				.OnClicked(this, &SAICopilotWindow::OnClearChatClicked)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2)
			[
				SNew(SButton)
				.Text(LOCTEXT("SaveChatButton", "保存聊天"))
				.ToolTipText(LOCTEXT("SaveChatTooltip", "保存当前对话到日志"))
				.OnClicked(this, &SAICopilotWindow::OnSaveChatHistoryClicked)
			]

			// Right: Settings
			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			.HAlign(HAlign_Right)
			[
				SNew(SButton)
				.Text(LOCTEXT("SettingsButton", "设置"))
				.ToolTipText(LOCTEXT("SettingsTooltip", "配置 API Key 和模型"))
				.OnClicked(this, &SAICopilotWindow::OnSettingsClicked)
			]
		]

		// Chat History Area
		+ SVerticalBox::Slot()
		.FillHeight(1.0f)
		.Padding(5)
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			.Padding(5)
			[
				SAssignNew(ChatScrollBox, SScrollBox)
			]
		]

		// Context Input
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(5)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("ContextLabel", "上下文 (选中的蓝图/节点):"))
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0, 5)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				[
					SNew(SBox)
					.HeightOverride(80)
					[
						SAssignNew(ContextTextBox, SMultiLineEditableTextBox) // Assign to member
						.HintText(LOCTEXT("ContextHint", "此处粘贴上下文信息..."))
					]
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(5, 0, 0, 0)
				[
					// NEW: Button to Add Selection Context
					SNew(SButton)
					.Text(LOCTEXT("AddContextButton", "获取选中"))
					.ToolTipText(LOCTEXT("AddContextTooltip", "获取选中的资产或蓝图节点文本"))
					.OnClicked(this, &SAICopilotWindow::OnAddSelectionContextClicked)
				]
			]
		]

		// Prompt Input Header
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(5, 5, 5, 0)
		[
			SNew(STextBlock)
			.Text(LOCTEXT("PromptLabel", "发送给 AI 的消息:"))
		]
		
		// Prompt Input Box
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(5, 0, 5, 5)
		[
			SNew(SBox)
			.MinDesiredHeight(50)
			[
				SAssignNew(InputTextBox, SMultiLineEditableTextBox)
				.HintText(LOCTEXT("InputHint", "询问代码或蓝图逻辑..."))
				.OnTextCommitted(this, &SAICopilotWindow::OnTextCommitted)
			]
		]

		// Send Buttons
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(5)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			.Padding(2)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.Text(LOCTEXT("SendButton", "发送"))
				.OnClicked(this, &SAICopilotWindow::OnSendClicked)
			]
			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			.Padding(2)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.Text(LOCTEXT("GenBPButton", "生成蓝图 (Python)"))
				.OnClicked(this, &SAICopilotWindow::OnGenerateBlueprintClicked)
			]
		]

		// Python Output with Undo/Redo
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(5)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("PythonCodeLabel", "生成的 Python 代码:"))
				]
				
				// Code Undo/Redo Controls
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SAssignNew(UndoButton, SButton) // Assign to member
					.Text(FText::FromString(TEXT("< Undo")))
					.ToolTipText(LOCTEXT("UndoCodeTooltip", "撤销代码更改"))
					.OnClicked(this, &SAICopilotWindow::OnUndoCodeClicked)
					.IsEnabled(false) // Initially disabled
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(5, 0, 0, 0)
				[
					SAssignNew(RedoButton, SButton) // Assign to member
					.Text(FText::FromString(TEXT("Redo >")))
					.ToolTipText(LOCTEXT("RedoCodeTooltip", "重做代码更改"))
					.OnClicked(this, &SAICopilotWindow::OnRedoCodeClicked)
					.IsEnabled(false) // Initially disabled
				]
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0, 5)
			[
				SNew(SBox)
				.MinDesiredHeight(120)
				[
					SAssignNew(PythonCodeBox, SMultiLineEditableTextBox)
					.IsReadOnly(false)
					.HintText(LOCTEXT("PythonCodeHint", "生成的 Python 脚本将显示在此处..."))
					.BackgroundColor(FLinearColor(0.02f, 0.02f, 0.02f))
					.TextStyle(FAppStyle::Get(), "Monospace") // Use Monospace font if available
				]
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0, 5)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.Text(LOCTEXT("RunPythonButton", "运行 Python 脚本"))
				.OnClicked(this, &SAICopilotWindow::OnRunPythonClicked)
			]
		]
	];
}

FReply SAICopilotWindow::OnSendClicked()
{
	const UAICopilotSettings* Settings = GetDefault<UAICopilotSettings>();
	FString ApiEndpoint = Settings->ApiUrl;
	FString ApiKey = Settings->ApiKey;
	FString ModelName = Settings->ModelName;

	FString UserInput = InputTextBox->GetText().ToString();
	if (UserInput.IsEmpty()) return FReply::Handled();

	// Only require API Key if not using Ollama (Ollama often runs without auth locally)
	if (ApiKey.IsEmpty() && Settings->ModelProvider != EAICopilotModelProvider::Ollama)
	{
		AddMessage("System", "Please configure your API Key in Settings.");
		return FReply::Handled();
	}

	InputTextBox->SetText(FText::GetEmpty());

	// Construct HTTP Request
	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
	
	Request->OnProcessRequestComplete().BindSP(this, &SAICopilotWindow::OnResponseReceived);
	Request->SetVerb("POST");
	Request->SetHeader("Content-Type", "application/json");

	// Add the user message to history NOW
	AddMessage("User", UserInput);

	// Create JSON Payload
	TSharedPtr<FJsonObject> JsonRequest = MakeShareable(new FJsonObject);
	FString RequestBody;

	// Handle Google Gemini Native API
	if (Settings->ModelProvider == EAICopilotModelProvider::GeminiNative)
	{
		// 1. URL with Key
		FString UrlWithKey = FString::Printf(TEXT("%s?key=%s"), *ApiEndpoint, *ApiKey);
		Request->SetURL(UrlWithKey);
		
		// 2. Build JSON (contents: [{role: "user", parts: [{text: "..."}]}])
		TArray<TSharedPtr<FJsonValue>> ContentsJson;

		// Note: Gemini Native expects "parts" array with "text" field
		// And usually context/system prompt is just prepended to first message

		FString SystemContext;
		if (ContextTextBox.IsValid() && !ContextTextBox->GetText().IsEmpty())
		{
			SystemContext = TEXT("System Context:\n") + ContextTextBox->GetText().ToString() + TEXT("\n\n");
		}

		for (int32 i = 0; i < ChatHistory.Num(); i++)
		{
			const FAIChatMessage& Msg = ChatHistory[i];
			
			TSharedPtr<FJsonObject> TurnObj = MakeShareable(new FJsonObject);
			// Gemini Role Mapping: "user" -> "user", "assistant" -> "model"
			FString Role = (Msg.Role.ToLower() == "assistant" || Msg.Role.ToLower() == "ai") ? "model" : "user";
			TurnObj->SetStringField("role", Role);

			FString ContentStr = Msg.Content;
			// Prepend context to the very first user message 
			if (i == 0 && Role == "user" && !SystemContext.IsEmpty())
			{
				ContentStr = SystemContext + ContentStr;
				SystemContext.Empty(); 
			}

			TArray<TSharedPtr<FJsonValue>> Parts;
			TSharedPtr<FJsonObject> PartObj = MakeShareable(new FJsonObject);
			PartObj->SetStringField("text", ContentStr);
			Parts.Add(MakeShareable(new FJsonValueObject(PartObj)));

			TurnObj->SetArrayField("parts", Parts);
			ContentsJson.Add(MakeShareable(new FJsonValueObject(TurnObj)));
		}
		
		JsonRequest->SetArrayField("contents", ContentsJson);
	}
	else 
	{
		// Standard OpenAI Format
		Request->SetURL(ApiEndpoint);
		if (!ApiKey.IsEmpty())
		{
			Request->SetHeader("Authorization", FString::Printf(TEXT("Bearer %s"), *ApiKey));
		}

		JsonRequest->SetStringField("model", ModelName);
		
		TArray<TSharedPtr<FJsonValue>> MessagesJson;

		// System/Context
		if (ContextTextBox.IsValid() && !ContextTextBox->GetText().IsEmpty())
		{
			TSharedPtr<FJsonObject> SysMsg = MakeShareable(new FJsonObject);
			SysMsg->SetStringField("role", "system");
			FString ContextStr = TEXT("Context:\n") + ContextTextBox->GetText().ToString();
			SysMsg->SetStringField("content", ContextStr);
			MessagesJson.Add(MakeShareable(new FJsonValueObject(SysMsg)));
		}

        // History
		for (const FAIChatMessage& Msg : ChatHistory)
		{
			TSharedPtr<FJsonObject> MsgObj = MakeShareable(new FJsonObject);
			MsgObj->SetStringField("role", Msg.Role.ToLower());
			MsgObj->SetStringField("content", Msg.Content);
			MessagesJson.Add(MakeShareable(new FJsonValueObject(MsgObj)));
		}
		
		JsonRequest->SetArrayField("messages", MessagesJson);
	}

	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBody);
	FJsonSerializer::Serialize(JsonRequest.ToSharedRef(), Writer);

	Request->SetContentAsString(RequestBody);
	Request->ProcessRequest();

	return FReply::Handled();
}

FReply SAICopilotWindow::OnSettingsClicked()
{
	TSharedRef<SWindow> SettingsWindow = SNew(SWindow)
		.Title(LOCTEXT("SettingsWindowTitle", "AI Copilot Settings"))
		.ClientSize(FVector2D(400, 200))
		.SupportsMaximize(false)
		.SupportsMinimize(false);

	TSharedRef<SAICopilotSettings> SettingsWidget = SNew(SAICopilotSettings);
	SettingsWidget->SetParentWindow(SettingsWindow);

	SettingsWindow->SetContent(SettingsWidget);

	FSlateApplication::Get().AddWindow(SettingsWindow);

	return FReply::Handled();
}

void SAICopilotWindow::OnTextCommitted(const FText& Text, ETextCommit::Type CommitMethod)
{
	if (CommitMethod == ETextCommit::OnEnter)
	{
		OnSendClicked();
	}
}

void SAICopilotWindow::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	if (!bWasSuccessful || !Response.IsValid())
	{
		AddMessage("System", "Error: Request failed.");
		return;
	}

	if (Response->GetResponseCode() != 200)
	{
		AddMessage("System", FString::Printf(TEXT("Error %d: %s"), Response->GetResponseCode(), *Response->GetContentAsString()));
		return;
	}

	TSharedPtr<FJsonObject> JsonResponse;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());

	if (FJsonSerializer::Deserialize(Reader, JsonResponse))
	{
		// Check for OpenAI / Gemini (OpenAI) format
		const TArray<TSharedPtr<FJsonValue>>* Choices;
		if (JsonResponse->TryGetArrayField("choices", Choices) && Choices->Num() > 0)
		{
			TSharedPtr<FJsonObject> Choice = (*Choices)[0]->AsObject();
			TSharedPtr<FJsonObject> Message = Choice->GetObjectField("message");
			FString Content = Message->GetStringField("content");
			
			AddMessage("AI", Content);
		}
		// Check for Gemini Native Format
        // { "candidates": [ { "content": { "parts": [ { "text": "..." } ] } } ] }
        else 
        {
             const TArray<TSharedPtr<FJsonValue>>* Candidates;
             if (JsonResponse->TryGetArrayField("candidates", Candidates) && Candidates->Num() > 0)
             {
                 TSharedPtr<FJsonObject> Candidate = (*Candidates)[0]->AsObject();
                 TSharedPtr<FJsonObject> ContentObj = Candidate->GetObjectField("content");
                 const TArray<TSharedPtr<FJsonValue>>* Parts;
                 if (ContentObj->TryGetArrayField("parts", Parts) && Parts->Num() > 0)
                 {
                      TSharedPtr<FJsonObject> Part = (*Parts)[0]->AsObject();
                      FString Text = Part->GetStringField("text");
                      AddMessage("AI", Text);
                 }
             }
        }
	}
}

void SAICopilotWindow::OnBlueprintResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	if (!bWasSuccessful || !Response.IsValid())
	{
		AddMessage("System", "Error: BP Generation Request failed.");
		return;
	}

	if (Response->GetResponseCode() != 200)
	{
		AddMessage("System", FString::Printf(TEXT("Error %d: %s"), Response->GetResponseCode(), *Response->GetContentAsString()));
		return;
	}

	TSharedPtr<FJsonObject> JsonResponse;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());

	if (FJsonSerializer::Deserialize(Reader, JsonResponse))
	{
		const TArray<TSharedPtr<FJsonValue>>* Choices;
		if (JsonResponse->TryGetArrayField("choices", Choices) && Choices->Num() > 0)
		{
			TSharedPtr<FJsonObject> Choice = (*Choices)[0]->AsObject();
			TSharedPtr<FJsonObject> Message = Choice->GetObjectField("message");
			FString Content = Message->GetStringField("content");

			// Extract Python Code from Markdown
			FString PythonCode;
			int32 StartIdx = Content.Find("```python");
			if (StartIdx == INDEX_NONE) StartIdx = Content.Find("```");
			
			if (StartIdx != INDEX_NONE)
			{
				int32 EndIdx = Content.Find("```", ESearchCase::IgnoreCase, ESearchDir::FromStart, StartIdx + 8); // Skip ```python
				if (EndIdx != INDEX_NONE)
				{
					// Extract
					int32 CodeStart = StartIdx + (Content.Find("python", ESearchCase::IgnoreCase, ESearchDir::FromStart, StartIdx) != INDEX_NONE ? 9 : 3);
					// Skip newline if present
					if (CodeStart < Content.Len() && Content[CodeStart] == '\n') CodeStart++;
					
					PythonCode = Content.Mid(CodeStart, EndIdx - CodeStart);
				}
				else
				{
					PythonCode = Content; // Fallback
				}
			}
			else
			{
				PythonCode = Content;
			}
			
			AddMessage("AI", "Generated Python Script. Review code below and click 'Run'.");
			SetPythonCode(PythonCode);
		}
	}
}

FReply SAICopilotWindow::OnGenerateBlueprintClicked()
{
	FString UserPrompt = InputTextBox->GetText().ToString();
	if (UserPrompt.IsEmpty()) return FReply::Handled();

	const UAICopilotSettings* Settings = GetDefault<UAICopilotSettings>();
	if (Settings->ApiKey.IsEmpty() && Settings->ModelProvider != EAICopilotModelProvider::Ollama)
	{
		AddMessage("System", "Please set API Key in settings.");
		return FReply::Handled();
	}

	AddMessage("User", "Generating Blueprint for: " + UserPrompt);
	// Clear the input box after reading the prompt
	InputTextBox->SetText(FText::GetEmpty());

	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
	Request->OnProcessRequestComplete().BindSP(this, &SAICopilotWindow::OnBlueprintResponseReceived);
	Request->SetURL(Settings->ApiUrl);
	Request->SetVerb("POST");
	Request->SetHeader("Content-Type", "application/json");
	if (!Settings->ApiKey.IsEmpty())
	{
		Request->SetHeader("Authorization", FString::Printf(TEXT("Bearer %s"), *Settings->ApiKey));
	}

	TSharedPtr<FJsonObject> JsonRequest = MakeShareable(new FJsonObject);
	JsonRequest->SetStringField("model", Settings->ModelName);

	TArray<TSharedPtr<FJsonValue>> MessagesJson;

	// System Prompt
	TSharedPtr<FJsonObject> SysMsg = MakeShareable(new FJsonObject);
	SysMsg->SetStringField("role", "system");
	SysMsg->SetStringField("content", "You are an expert Unreal Engine 5 Technical Artist. Write a Python script using the `unreal` module to create the requested Blueprint/Asset. Return valid Python code inside ```python blocks. Ensure the code handles asset creation and saving.");
	MessagesJson.Add(MakeShareable(new FJsonValueObject(SysMsg)));

	// User Prompt
	TSharedPtr<FJsonObject> UserMsg = MakeShareable(new FJsonObject);
	UserMsg->SetStringField("role", "user");
	UserMsg->SetStringField("content", UserPrompt);
	MessagesJson.Add(MakeShareable(new FJsonValueObject(UserMsg)));

	JsonRequest->SetArrayField("messages", MessagesJson);

	FString RequestBody;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBody);
	FJsonSerializer::Serialize(JsonRequest.ToSharedRef(), Writer);

	Request->SetContentAsString(RequestBody);
	Request->ProcessRequest();

	return FReply::Handled();
}

FReply SAICopilotWindow::OnRunPythonClicked()
{
	FString Code = PythonCodeBox->GetText().ToString();
	if (Code.IsEmpty()) return FReply::Handled();

	IPythonScriptPlugin* PythonPlugin = IPythonScriptPlugin::Get();
	if (PythonPlugin && PythonPlugin->IsPythonAvailable())
	{
		PythonPlugin->ExecPythonCommand(*Code);
		AddMessage("System", "Python script executed.");
	}
	else
	{
		AddMessage("System", "Error: PythonScriptPlugin not available or Python not initialized.");
	}
	
	return FReply::Handled();
}

void SAICopilotWindow::SetPythonCode(const FString& Code)
{
	if (PythonCodeBox.IsValid())
	{
		PythonCodeBox->SetText(FText::FromString(Code));
		PushCodeHistory(Code);
	}
}

void SAICopilotWindow::AppendContext(const FString& NewContext)
{
	if (ContextTextBox.IsValid())
	{
		FString Current = ContextTextBox->GetText().ToString();
		if (!Current.IsEmpty())
		{
			Current += TEXT("\n\n");
		}
		Current += NewContext;
		ContextTextBox->SetText(FText::FromString(Current));
	}
}

FReply SAICopilotWindow::OnAddSelectionContextClicked()
{
	FString SelectedContext;
	bool bFoundSelection = false;

	// 1. Get Selected Actors (Level Editor)
	if (GEditor)
	{
		USelection* SelectedActors = GEditor->GetSelectedActors();
		if (SelectedActors && SelectedActors->Num() > 0)
		{
			SelectedContext += TEXT("Selected Level Actors:\n");
			for (FSelectionIterator It(*SelectedActors); It; ++It)
			{
				if (AActor* Actor = Cast<AActor>(*It))
				{
					SelectedContext += FString::Printf(TEXT("- %s (Class: %s) Location: %s\n"), 
						*Actor->GetActorLabel(), 
						*Actor->GetClass()->GetName(),
						*Actor->GetActorLocation().ToString());
					bFoundSelection = true;
				}
			}
			SelectedContext += TEXT("\n");
		}
	
		// 2. Get Selected Objects (Content Browser items are often here)
		USelection* SelectedObjects = GEditor->GetSelectedObjects();
		if (SelectedObjects && SelectedObjects->Num() > 0)
		{
			// Filter out actors we already logged
			bool bHeaderAdded = false;
			for (FSelectionIterator It(*SelectedObjects); It; ++It)
			{
				UObject* Obj = *It;
				if (Obj && !Obj->IsA<AActor>()) // Skip actors
				{
					if (!bHeaderAdded)
					{
						SelectedContext += TEXT("Selected Objects/Assets:\n");
						bHeaderAdded = true;
					}
					
					SelectedContext += FString::Printf(TEXT("- %s (Class: %s) Path: %s\n"), 
						*Obj->GetName(), 
						*Obj->GetClass()->GetName(),
						*Obj->GetPathName());
					bFoundSelection = true;
				}
			}
			if (bHeaderAdded) SelectedContext += TEXT("\n");
		}
	}
	
	// 3. Try to get Graph Nodes via Copy Buffer
	FString ClipboardContent;
	FPlatformApplicationMisc::ClipboardPaste(ClipboardContent);
	if (ClipboardContent.Contains("Begin Object") && (ClipboardContent.Contains("Class=/Script/BlueprintGraph") || ClipboardContent.Contains("EdGraphNode")))
	{
		 SelectedContext += TEXT("Clipboard Content (Potential Nodes):\n");
		 SelectedContext += ClipboardContent.Left(2000); // Limit size
		 if (ClipboardContent.Len() > 2000) SelectedContext += TEXT("... (Truncated)");
		 SelectedContext += TEXT("\n");
		 bFoundSelection = true;
	}

	if (!bFoundSelection)
	{
		SelectedContext = TEXT("[No Selection found. Copy Blueprint Nodes (Ctrl+C) to context]");
	}

	AppendContext(SelectedContext);
	return FReply::Handled();
}

void SAICopilotWindow::AddMessage(const FString& Role, const FString& Content)
{
	// Ensure role for history is correct (User/AI -> user/assistant)
	FString ApiRole = (Role == "User") ? "user" : "assistant";
	
	// Only add to history if not already there (simple check, or just always add)
	// We call AddMessage for User inputs and AI responses.
	ChatHistory.Add({ApiRole, Content});

	// Use CreateChatBubble for visualization
	CreateChatBubble(Role, Content);
}

void SAICopilotWindow::CreateChatBubble(const FString& InRole, const FString& Content)
{
	bool bIsUser = (InRole == "User");
	
	// Chat Bubble Widget
	TSharedPtr<SWidget> ChatBubble;

    auto MessageTextBlock = SNew(SMultiLineEditableTextBox)
        .Text(FText::FromString(Content))
        .IsReadOnly(true)
        .AutoWrapText(true)
        .BackgroundColor(FLinearColor::Transparent)
        .TextStyle(FAppStyle::Get(), "NormalText");

    // Start with a generic border
    auto BubbleBorder = SNew(SBorder)
        .Padding(FMargin(10))
        .BorderImage(FAppStyle::GetBrush(bIsUser ? "ToolPanel.GroupBorder" : "Brushes.Panel"));
		
	if (bIsUser)
	{
		BubbleBorder->SetBorderBackgroundColor(FLinearColor(0.2f, 0.4f, 0.8f)); // User Blue
	}
	else
	{
		BubbleBorder->SetBorderBackgroundColor(FLinearColor(0.2f, 0.2f, 0.2f)); // AI Dark
	}

    BubbleBorder->SetContent(MessageTextBlock);

	ChatScrollBox->AddSlot()
	.Padding(5)
	.HAlign(bIsUser ? HAlign_Right : HAlign_Left) // Alignment based on role
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(STextBlock)
			.Text(FText::FromString(InRole))
			.ColorAndOpacity(FLinearColor::Gray)
			.Font(FCoreStyle::GetDefaultFontStyle("Regular", 8))
			.Justification(bIsUser ? ETextJustify::Right : ETextJustify::Left)
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(0, 2)
		[
            SNew(SBox)
            .MaxDesiredWidth(600) // Limit width of bubble
            [
			    BubbleBorder
            ]
		]
	];
	
	ChatScrollBox->ScrollToEnd();
}

FReply SAICopilotWindow::OnClearChatClicked()
{
	ChatHistory.Empty();
	if(ChatScrollBox.IsValid())
	{
		ChatScrollBox->ClearChildren();
	}
	AddMessage("System", "Chat cleared.");
	return FReply::Handled();
}

FReply SAICopilotWindow::OnSaveChatHistoryClicked()
{
    FString FilePath = FPaths::ProjectSavedDir() / TEXT("AICopilot_ChatHistory.txt");
    FString OutputString;
    
    for(const auto& Msg : ChatHistory)
    {
        OutputString += FString::Printf(TEXT("[%s]: %s\n\n"), *Msg.Role, *Msg.Content);
    }
    
    if(FFileHelper::SaveStringToFile(OutputString, *FilePath))
    {
        AddMessage("System", FString::Printf(TEXT("Chat history saved to: %s"), *FilePath));
        FPlatformProcess::ExploreFolder(*FilePath);
    }
    else
    {
        AddMessage("System", "Failed to save chat history.");
    }

	return FReply::Handled();
}

void SAICopilotWindow::PushCodeHistory(const FString& NewCode)
{
	// If we are not at the end of the history (i.e. we undid some steps), remove the future steps
	if(CurrentCodeIndex < CodeHistory.Num() - 1)
	{
		CodeHistory.SetNum(CurrentCodeIndex + 1);
	}
    
    // push new code
    CodeHistory.Add(NewCode);
    CurrentCodeIndex++;
    
    UpdateUndoRedoState();
}

FReply SAICopilotWindow::OnUndoCodeClicked()
{
   if(CurrentCodeIndex > 0)
   {
       CurrentCodeIndex--;
       FString PreviousCode = CodeHistory[CurrentCodeIndex];
       
       // Update UI without pushing to history again
       if(PythonCodeBox.IsValid())
       {
           PythonCodeBox->SetText(FText::FromString(PreviousCode));
       }
       
       UpdateUndoRedoState();
   }
   return FReply::Handled();
}

FReply SAICopilotWindow::OnRedoCodeClicked()
{
    if(CurrentCodeIndex < CodeHistory.Num() - 1)
    {
        CurrentCodeIndex++;
        FString NextCode = CodeHistory[CurrentCodeIndex];
        
        if(PythonCodeBox.IsValid())
        {
             PythonCodeBox->SetText(FText::FromString(NextCode));
        }
        
        UpdateUndoRedoState();
    }
    return FReply::Handled();
}

void SAICopilotWindow::UpdateUndoRedoState()
{
    if(UndoButton.IsValid())
    {
        UndoButton->SetEnabled(CurrentCodeIndex > 0);
    }
    if(RedoButton.IsValid())
    {
        RedoButton->SetEnabled(CurrentCodeIndex < CodeHistory.Num() - 1);
    }
}

#undef LOCTEXT_NAMESPACE
